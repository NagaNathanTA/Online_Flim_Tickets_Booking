package com.bus;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class FilmBookingSystem {
	 public static void main(String[] args) {
	        // Sender's email address and password
	        String senderEmail = "naganathanta2002ems@gmail.com";
	        String senderPassword = "iavv imqv gbxs efva";

	        // Recipient's email address
	        String recipientEmail = "naganathanta625@gmail.com";

	        // Set up mail server properties
	        Properties properties = new Properties();
	        properties.put("mail.smtp.auth", "true");
	        properties.put("mail.smtp.starttls.enable", "true");
	        properties.put("mail.smtp.host", "smtp.gmail.com");
	        properties.put("mail.smtp.port", "587");
	        


	        // Create a session with authentication
	        Session session = Session.getInstance(properties, new Authenticator() {
	            @Override
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(senderEmail, senderPassword);
	            }
	        });

	        try {
	            // Create a MimeMessage object
	            Message message = new MimeMessage(session);

	            // Set the sender and recipient addresses
	            message.setFrom(new InternetAddress(senderEmail));
	            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));

	            // Set the email subject and content
	            message.setSubject("Booking Details");
	            message.setText("Here are your booking details:\n\n"
	                    + "Movie: Maaveeran\n"
	                    + "Date: September 14, 2023\n"
	                    + "Time: 3:00 PM\n"
	                    + "Number of Tickets: 3\n"
	                    + "Seat Number: 32,33,34");

	            // Send the message
	            Transport.send(message);

	            System.out.println("Email sent successfully!");

	        } catch (MessagingException e) {
	            e.printStackTrace();
	            System.out.println("Error sending email: " + e.getMessage());
	        }
	    }
}
